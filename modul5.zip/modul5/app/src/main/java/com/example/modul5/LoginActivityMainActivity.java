package com.example.modul5;

import android.app.Activity;

public class LoginActivityMainActivity extends Activity {
}
